
# WMSSANCHEZ

Sistema web integral para la **gestión de empleados, horarios, puestos, programación e indicadores de desempeño**. Desarrollado con **Next.js, Prisma y TailwindCSS**, e incluye funcionalidades modernas como **exportación**, **gráficas** y **dashboard visual**.

## 🚀 Características principales

- 🧑‍💼 Módulo de **Empleados** (CRUD + búsqueda)
- 🧭 Gestión de **Puestos** y descripción
- 🕒 Asignación de **Horarios** por día
- 📊 Captura de **Indicadores** por día y porcentaje
- 📅 **Programación semanal** de tareas por puesto
- 📈 Módulo de **Reportes**: semanal, mensual y anual
- 📉 **Gráficas** interactivas (Recharts)
- 🧾 Exportación a **Excel**, **PDF** y **ZIP**
- 🧭 Dashboard visual con tarjetas resumen
- 🧭 Barra lateral de navegación con íconos (Lucide)
- 🌐 Preparado para despliegue en **Vercel**

## 🧑‍💻 Tecnologías utilizadas

- Next.js
- Prisma ORM
- Tailwind CSS
- Lucide Icons
- jsPDF + xlsx
- Recharts

## ⚙️ Instalación local

```bash
git clone https://github.com/TU_USUARIO/WMSSANCHEZ.git
cd WMSSANCHEZ
npm install
npx prisma generate
npm run dev
```

Crear archivo `.env.local`:

```env
DATABASE_URL=postgresql://usuario:contraseña@host:puerto/nombre_db
```

## 📦 Scripts disponibles

```bash
npm run dev       # Ejecuta el servidor local
npm run build     # Compila para producción
npm run start     # Inicia app en producción
```

## 📤 Exportación

Cada módulo permite exportar su información como:
- Excel (.xlsx)
- PDF (.pdf)
- Comprimido ZIP (opcional)

## 📊 Dashboard

El dashboard muestra resúmenes visuales como:
- Total empleados
- Indicadores creados
- Tareas programadas
- Capturas semanales

## 🖼️ Vista previa

![Captura WMSSANCHEZ](public/screenshot.jpg)

## 📝 Licencia

Este proyecto es de uso interno. Todos los derechos reservados © Yokar Sánchez.
